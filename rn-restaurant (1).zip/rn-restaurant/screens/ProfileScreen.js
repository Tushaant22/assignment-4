import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, Pressable, Alert, SafeAreaView, ScrollView } from 'react-native';
import { useProfile } from '../context/ProfileContext';

export default function ProfileScreen() {
  const { profile, saveProfile, logout } = useProfile();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (profile) {
      setName(profile.name || '');
      setEmail(profile.email || '');
      setPhone(profile.phone || '');
    }
  }, [profile]);

  const canSave = name.trim() && /.+@.+\..+/.test(email) && phone.trim().length >= 7;

  const onSave = async () => {
    if (!canSave) return;
    await saveProfile({ name, email, phone });
    Alert.alert('Saved', 'Your profile has been updated.');
  };

  const onLogout = async () => {
    await logout();
    Alert.alert('Logged out', 'Profile data cleared.');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f7f7f7' }}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Your Profile</Text>
        <TextInput placeholder="Full Name" value={name} onChangeText={setName} style={styles.input} />
        <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={styles.input} keyboardType="email-address" autoCapitalize="none" />
        <TextInput placeholder="Phone" value={phone} onChangeText={setPhone} style={styles.input} keyboardType="phone-pad" />

        <Pressable onPress={onSave} disabled={!canSave} style={[styles.btn, !canSave && styles.btnDisabled]}>
          <Text style={styles.btnText}>Save Changes</Text>
        </Pressable>

        <Pressable onPress={onLogout} style={[styles.btn, { backgroundColor: '#c0392b' }]}>
          <Text style={styles.btnText}>Log out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  title: { fontSize: 22, fontWeight: '800', marginBottom: 12 },
  input: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    borderWidth: 1,
    borderColor: '#e5e5e5',
    marginBottom: 12,
  },
  btn: {
    backgroundColor: '#222',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 8
  },
  btnDisabled: { backgroundColor: '#bbb' },
  btnText: { color: '#fff', fontWeight: '700' },
});
