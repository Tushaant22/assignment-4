import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useProfile } from '../context/ProfileContext';

export default function OnboardingScreen({ navigation }) {
  const { saveProfile } = useProfile();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const valid = useMemo(() => {
    const emailOk = /.+@.+\..+/.test(email);
    return name.trim().length > 1 && emailOk && phone.trim().length >= 7;
  }, [name, email, phone]);

  const submit = async () => {
    if (!valid) return;
    await saveProfile({ name, email, phone });
    navigation.reset({ index: 0, routes: [{ name: 'Home' }] });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f7f7f7' }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <View style={styles.container}>
          <Text style={styles.header}>Welcome!</Text>
          <Text style={styles.sub}>Let’s set up your profile to personalize your experience.</Text>

          <TextInput placeholder="Full Name" value={name} onChangeText={setName} style={styles.input} />
          <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={styles.input} keyboardType="email-address" autoCapitalize="none" />
          <TextInput placeholder="Phone" value={phone} onChangeText={setPhone} style={styles.input} keyboardType="phone-pad" />

          <Pressable disabled={!valid} onPress={submit} style={[styles.btn, !valid && styles.btnDisabled]}>
            <Text style={styles.btnText}>Next</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  header: { fontSize: 28, fontWeight: '800', marginBottom: 8 },
  sub: { color: '#555', marginBottom: 24 },
  input: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    borderWidth: 1,
    borderColor: '#e5e5e5',
    marginBottom: 12,
  },
  btn: {
    backgroundColor: '#222',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 8
  },
  btnDisabled: { backgroundColor: '#bbb' },
  btnText: { color: '#fff', fontWeight: '700' },
});
