import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, SafeAreaView, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { CATEGORIES, MENU } from '../data/menu';
import CategoryChips from '../components/CategoryChips';
import MenuItemCard from '../components/MenuItemCard';
import { useProfile } from '../context/ProfileContext';

export default function HomeScreen() {
  const nav = useNavigation();
  const { profile } = useProfile();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState(null);

  const data = useMemo(() => {
    const q = query.toLowerCase();
    return MENU.filter(item => {
      const matchQ = !q || item.title.toLowerCase().includes(q) || item.description.toLowerCase().includes(q);
      const matchC = !category || item.category === category;
      return matchQ && matchC;
    });
  }, [query, category]);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f7f7f7' }}>
      <View style={styles.header}>
        <Text style={styles.brand}>Aurora Bistro</Text>
        <Pressable onPress={() => nav.navigate('Profile')}>
          <Text style={styles.profileLink}>{profile?.name ? profile.name : 'Profile'}</Text>
        </Pressable>
      </View>

      <View style={styles.hero}>
        <Text style={styles.heroTitle}>Fresh • Cozy • Local</Text>
        <Text style={styles.heroText}>Browse the menu or search for a dish below.</Text>
        <TextInput
          placeholder="Search dishes..."
          value={query}
          onChangeText={setQuery}
          style={styles.search}
        />
      </View>

      <View style={{ paddingHorizontal: 16 }}>
        <Text style={styles.sectionTitle}>Menu Categories</Text>
        <CategoryChips categories={CATEGORIES} selected={category} onSelect={setCategory} />

        <Text style={styles.sectionTitle}>Dishes</Text>
        <FlatList
          data={data}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <MenuItemCard item={item} />}
          contentContainerStyle={{ paddingBottom: 24 }}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 8,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderColor: '#eee'
  },
  brand: { fontSize: 20, fontWeight: '800' },
  profileLink: { color: '#2a6', fontWeight: '700' },
  hero: { backgroundColor: '#fff', padding: 16, marginBottom: 12 },
  heroTitle: { fontSize: 22, fontWeight: '800', marginBottom: 6 },
  heroText: { color: '#666', marginBottom: 12 },
  search: { backgroundColor: '#f2f2f2', padding: 12, borderRadius: 10 },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginVertical: 8 },
});
