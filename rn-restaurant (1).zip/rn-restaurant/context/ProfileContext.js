import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ProfileContext = createContext();

export function ProfileProvider({ children }) {
  const [profile, setProfile] = useState(null);
  const [profileLoaded, setProfileLoaded] = useState(false);
  const [isFirstLaunch, setIsFirstLaunch] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem('profile');
        if (stored) {
          const p = JSON.parse(stored);
          setProfile(p);
          setIsFirstLaunch(false);
        } else {
          setIsFirstLaunch(true);
        }
      } catch (e) {
        console.warn('Failed to load profile', e);
      } finally {
        setProfileLoaded(true);
      }
    })();
  }, []);

  const saveProfile = async (data) => {
    setProfile(data);
    await AsyncStorage.setItem('profile', JSON.stringify(data));
    setIsFirstLaunch(false);
  };

  const logout = async () => {
    setProfile(null);
    await AsyncStorage.removeItem('profile');
    setIsFirstLaunch(true);
  };

  return (
    <ProfileContext.Provider value={{ profile, profileLoaded, isFirstLaunch, saveProfile, logout }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  return useContext(ProfileContext);
}
