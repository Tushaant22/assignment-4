
# Restaurant Ordering App (Expo React Native)

This project implements the Assignment 5 requirements:
- Navigation header and hero section, search bar, categories (Starters, Mains, Desserts, Specials), and dishes list on **Home**.
- **Onboarding** shown on first launch with profile setup and a **Next** button disabled until valid.
- **Profile** screen shows data captured during onboarding; changes persist across restarts; **Log out** clears saved profile.
- **Stack navigation** with Back button (handled automatically by the native stack).
- Git instructions included below.

## Quick Start
1. Install Expo CLI and dependencies
```bash
npm i -g expo
npm install
```
2. Run
```bash
npm run start
```
Open on Android/iOS simulator or Expo Go.

## Project Structure
- `App.js`: Sets up React Navigation and mounts screens.
- `context/ProfileContext.js`: Handles profile state + AsyncStorage persistence.
- `screens/OnboardingScreen.js`: First-launch onboarding form.
- `screens/HomeScreen.js`: Header, hero, search, selectable categories, filtered dish list.
- `screens/ProfileScreen.js`: View/edit profile, save, and log out.
- `data/menu.js`: Menu categories and sample items.
- `components/CategoryChips.js`, `components/MenuItemCard.js`: UI components.

## Git & GitHub
```bash
git init
git add .
git commit -m "Assignment 5 initial submission"
git branch -M main
git remote add origin <YOUR_GITHUB_REPO_URL>
git push -u origin main
```

## Notes
- You can rename the brand in `HomeScreen` (`Aurora Bistro`) to match your chosen restaurant.
- To submit to a store, follow Expo's EAS Build docs.
