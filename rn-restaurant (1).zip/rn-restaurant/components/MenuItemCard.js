import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function MenuItemCard({ item }) {
  return (
    <View style={styles.card}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.subtitle} numberOfLines={2}>{item.description}</Text>
      </View>
      <Text style={styles.price}>${item.price.toFixed(2)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#fff',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  title: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  subtitle: { color: '#555' },
  price: { marginLeft: 12, fontWeight: '700' },
});
