import React from 'react';
import { View, Text, Pressable, StyleSheet, ScrollView } from 'react-native';

export default function CategoryChips({ categories, selected, onSelect }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.row}>
      {categories.map(cat => (
        <Pressable
          key={cat}
          onPress={() => onSelect(cat === selected ? null : cat)}
          style={[styles.chip, selected === cat && styles.active]}
        >
          <Text style={[styles.chipText, selected === cat && styles.activeText]}>{cat}</Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { marginVertical: 12 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#ccc',
    marginRight: 8,
    backgroundColor: '#fff'
  },
  active: { backgroundColor: '#222' },
  chipText: { color: '#222' },
  activeText: { color: '#fff' },
});
