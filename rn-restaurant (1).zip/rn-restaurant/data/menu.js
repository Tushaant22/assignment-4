export const CATEGORIES = ['Starters', 'Mains', 'Desserts', 'Specials'];

export const MENU = [
  { id: '1', title: 'Bruschetta', price: 8.5, category: 'Starters', description: 'Grilled bread with tomatoes and basil' },
  { id: '2', title: 'Caesar Salad', price: 9.0, category: 'Starters', description: 'Crisp romaine with creamy dressing' },
  { id: '3', title: 'Grilled Chicken', price: 16.5, category: 'Mains', description: 'Herb-marinated chicken breast' },
  { id: '4', title: 'Spaghetti Bolognese', price: 15.0, category: 'Mains', description: 'Rich meat sauce over pasta' },
  { id: '5', title: 'Chocolate Lava Cake', price: 7.0, category: 'Desserts', description: 'Warm cake with molten center' },
  { id: '6', title: 'Cheesecake', price: 7.5, category: 'Desserts', description: 'Classic NY-style cheesecake' },
  { id: '7', title: 'Chef Special Burger', price: 18.0, category: 'Specials', description: 'Signature burger of the day' },
  { id: '8', title: 'Seafood Paella', price: 22.0, category: 'Specials', description: 'Saffron rice with mixed seafood' },
];
